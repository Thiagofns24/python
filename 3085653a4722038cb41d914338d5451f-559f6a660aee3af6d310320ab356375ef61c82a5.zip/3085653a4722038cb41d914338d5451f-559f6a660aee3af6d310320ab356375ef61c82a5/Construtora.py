#Faça um programa que leia a largura e a altura de uma parede em metros. Calcule a sua área
#e a quantidade de tinta necessária para pintá-la, sabendo que cada litro de tinta pinta
#uma área de 2 metros quadrados.

print(f'Bem vindo a San Diego Construtora'.upper())
largura = int(input('\nInforme a largura da parede:'))
altura = int(input('\nInforme a altura da parede:'))
área = largura*altura
tinta = área/2
print(f'\nA área da sua parede é: {área}')
print(f'\nA quantidade de tinta necessária é: {tinta} Litros')

